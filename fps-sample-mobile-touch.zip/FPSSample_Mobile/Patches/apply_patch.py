#!/usr/bin/env python3
# Roda na RAIZ do projeto FPSSample: python3 apply_patch.py
# Faz o Game.cs consultar o input mobile antes do input clássico.
import io, os, sys

ARQ = "Assets/Scripts/Game/Main/Game.cs"
if not os.path.exists(ARQ):
    sys.exit("Rode este script na raiz do projeto FPSSample (não achei %s)" % ARQ)

src = io.open(ARQ, encoding="utf-8-sig").read()

def troca(old, new):
    global src
    if new in src:
        print("ja aplicado:", new.splitlines()[0][:60]); return
    if old not in src:
        sys.exit("trecho nao encontrado (versao diferente do Game.cs?):\n" + old)
    src = src.replace(old, new, 1)

troca('''        internal static float GetAxisRaw(string axis)
        {
            return blocks != Blocker.None ? 0.0f : UnityEngine.Input.GetAxisRaw(axis);
        }''',
'''        internal static float GetAxisRaw(string axis)
        {
            if (blocks != Blocker.None) return 0.0f;
            float mv = FPSSampleMobile.MobileInput.GetAxisRaw(axis);
            if (mv != 0.0f) return mv;
            return UnityEngine.Input.GetAxisRaw(axis);
        }''')

troca('''        internal static bool GetKey(KeyCode key)
        {
            return blocks != Blocker.None ? false : UnityEngine.Input.GetKey(key);
        }''',
'''        internal static bool GetKey(KeyCode key)
        {
            if (blocks != Blocker.None) return false;
            if (FPSSampleMobile.MobileInput.GetKey(key)) return true;
            return UnityEngine.Input.GetKey(key);
        }''')

troca('''        internal static bool GetKeyDown(KeyCode key)
        {
            return blocks != Blocker.None ? false : UnityEngine.Input.GetKeyDown(key);
        }''',
'''        internal static bool GetKeyDown(KeyCode key)
        {
            if (blocks != Blocker.None) return false;
            if (FPSSampleMobile.MobileInput.GetKeyDown(key)) return true;
            return UnityEngine.Input.GetKeyDown(key);
        }''')

troca('''        internal static bool GetMouseButton(int button)
        {
            return blocks != Blocker.None ? false : UnityEngine.Input.GetMouseButton(button);
        }''',
'''        internal static bool GetMouseButton(int button)
        {
            if (blocks != Blocker.None) return false;
            if (FPSSampleMobile.MobileInput.GetMouseButton(button)) return true;
            return UnityEngine.Input.GetMouseButton(button);
        }''')

io.open(ARQ, "w", encoding="utf-8").write(src)
print("Game.cs atualizado com sucesso. Copie a pasta Scripts/ para Assets/Scripts/Mobile/")
