# FPSSample no celular — controles touch + build

## Aviso importante (leia antes)
O FPSSample oficial usa **Unity 2018.3 + HDRP 4.6 (pipeline de alta definição)**.
Essa versão do HDRP **não suporta Android**: o build pode até sair, mas a cena
renderiza rosa/preto ou não abre. Só adicionar botões não resolve isso — seria
preciso reconverter materiais/shaders para URP ou Built-in (trabalho de semanas).

Num Redmi 13C (Helio G85) o HDRP também não rodaria liso nem se compilasse.
Recomendação: usar o FPSSample para estudar/PC, e no celular partir de um FPS
leve em URP (ex.: "Starter Assets – First Person" da Unity) com os mesmos
scripts de toque deste pacote.

## O que este pacote faz
- `Scripts/MobileInput.cs` — fonte central de input mobile.
- `Scripts/MobileTouchControls.cs` — joystick esquerdo (mover), arrastar na
  metade direita (olhar), botões FIRE / MIRA / JUMP / CROUCH / SPRINT / ARMA / RECARREGAR.
- `Scripts/MobileBootstrap.cs` — cria o painel sozinho no Android (não precisa editar cena).
- `apply_patch.py` — faz o `Game.cs` do FPSSample ler o input mobile primeiro.

## Instalar (2 minutos)
1. Copie `Scripts/` para `Assets/Scripts/Mobile/` do projeto.
2. Na raiz do projeto rode: `python3 apply_patch.py`
3. Abra no Unity Hub com **2018.3.8f1**, `File > Build Settings > Android > Switch Platform`, Build.
   - Player Settings: Scripting Backend IL2CPP (ARMv7), Graphics API OpenGL ES 3.0.
4. Se algum botão não fizer a ação certa, edite os `KeyCode` no topo de
   `MobileTouchControls.cs` para coincidir com os binds do FPSSample.

## Build sem PC (nuvem)
O workflow `.github/workflows/build-android.yml` compila o APK no GitHub Actions
(GameCI). Precisa de 3 secrets do seu Unity (conta gratuita):
`UNITY_EMAIL`, `UNITY_PASSWORD`, `UNITY_SERIAL` (serial do plano Personal).
Depois: Actions > Build Android > Run workflow > baixa o APK no artefato.
