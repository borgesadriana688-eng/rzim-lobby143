-- Montroy World - estilo Roblox (lobby, moedas, loja, obby, arena)
local S = core.get_mod_storage()

local coins = {}      -- [nome] = numero
local bought = {}     -- [nome] = {speed=..,jump=..}
local pvp = {}        -- [nome] = bool
local inArena = {}    -- [nome] = bool

local function carregar()
    local d = S:get_string("dados")
    if d and d ~= "" then
        local ok, t = pcall(core.deserialize, d)
        if ok and type(t) == "table" then
            coins  = t.coins  or {}
            bought = t.bought or {}
            pvp    = t.pvp    or {}
        end
    end
end

local function salvar()
    S:set_string("dados", core.serialize({coins = coins, bought = bought, pvp = pvp}))
end

local function rank(n)
    local c = coins[n] or 0
    if c >= 200 then return "DIAMANTE" elseif c >= 100 then return "OURO"
    elseif c >= 50 then return "PRATA" elseif c >= 20 then return "BRONZE" end
    return "INICIANTE"
end

local function hud(p)
    local n = p:get_player_name()
    local id = p:hud_add({
        hud_elem_type = "text",
        position = {x = 0.5, y = 0.02},
        alignment = {x = 0, y = 0},
        number = 0xFFFFD319,
        text = "MONTROY WORLD   Moedas: " .. (coins[n] or 0) .. "   Rank: " .. rank(n),
        scale = {x = 100, y = 100},
    })
    p:get_meta():set_int("hud_moedas", id)
end

local function atualizarHud(p)
    local n = p:get_player_name()
    local id = p:get_meta():get_int("hud_moedas")
    if id and id ~= 0 then
        p:hud_change(id, "text", "MONTROY WORLD   Moedas: " .. (coins[n] or 0) .. "   Rank: " .. rank(n))
    else
        hud(p)
    end
end

local function darMoedas(p, q)
    local n = p:get_player_name()
    coins[n] = (coins[n] or 0) + q
    atualizarHud(p)
    salvar()
end

-- ====== MOEDA (bloco coletavel que renasce) ======
core.register_node("mw_rbx:moeda", {
    description = "Moeda",
    tiles = {"default_gold_block.png"},
    walkable = false,
    sunlight_propagates = true,
    groups = {oddly_breakable_by_hand = 3, not_in_creative_inventory = 1},
    on_rightclick = function(pos, node, clicker)
        if clicker and clicker:is_player() then
            core.remove_node(pos)
            darMoedas(clicker, 1)
            core.chat_send_player(clicker:get_player_name(), core.colorize("#FFD319", "+1 moeda"))
            core.after(20, function()
                local nd = core.get_node_or_nil(pos)
                if nd and nd.name == "air" then core.set_node(pos, {name = "mw_rbx:moeda"}) end
            end)
        end
    end,
})

-- ====== PULA-PULA (obby, estilo Roblox) ======
core.register_node("mw_rbx:pulapula", {
    description = "Pula-pula",
    tiles = {"default_mese_block.png"},
    groups = {cracky = 1},
    on_walk_over = function(pos, node, walker)
        if walker and walker:is_player() then
            local v = walker:get_player_velocity()
            walker:add_player_velocity({x = v.x * 1.2, y = 14, z = v.z * 1.2})
            core.sound_play("default_glass_footstep", {to_player = walker:get_player_name(), gain = 0.5})
        end
    end,
})

-- ====== ARENA PVP ======
core.register_chatcommand("arena", {
    description = "Entra/sai da arena PvP",
    func = function(name)
        local p = core.get_player_by_name(name)
        if not p then return false, "Jogador offline" end
        if inArena[name] then
            inArena[name] = nil
            pvp[name] = false
            p:set_armor_groups({immortal = 1})
            core.chat_send_player(name, "Saiu da arena. PvP OFF.")
            local sp = core.find_node_near({x = 0, y = 10, z = 0}, 30, "default:stone")
            p:set_pos({x = 0, y = 12, z = 0})
        else
            inArena[name] = true
            pvp[name] = true
            p:set_armor_groups({fleshy = 100})
            p:set_pos({x = 40, y = 12, z = 40})
            core.chat_send_player(name, "Entrou na arena. PvP ON - cuidado!")
        end
        return true, "ok"
    end,
})

-- queda na arena = morre, volta pro lobby
core.register_on_dieplayer(function(player)
    local n = player:get_player_name()
    coins[n] = math.max(0, (coins[n] or 0) - 3)
    salvar()
    core.after(0.2, function()
        player:set_pos({x = 0, y = 14, z = 0})
        atualizarHud(player)
        core.chat_send_player(n, "Voce caiu: -3 moedas. Total: " .. (coins[n] or 0))
    end)
    return false
end)

-- ====== LOJA ======
local LOJA = {
    {id = "velocidade", nome = "Corrida +30%", preco = 10, aplica = function(p) p:set_physics_override({speed = 1.3}) end},
    {id = "pulo",       nome = "Pulo alto",    preco = 15, aplica = function(p) p:set_physics_override({jump = 1.5}) end},
    {id = "vida",       nome = "Vida extra",   preco = 20, aplica = function(p) p:set_hp(40) end},
}

core.register_chatcommand("loja", {
    description = "Abre a loja",
    func = function(name)
        local t = {"MOEDAS: " .. (coins[name] or 0)}
        for _, it in ipairs(LOJA) do
            local tem = bought[name] and bought[name][it.id]
            table.insert(t, string.format("/comprar %s  %d moedas  %s = %s", it.id, it.preco, it.nome, tem and "COMPRADO" or "disponivel"))
        end
        table.insert(t, "/arena  entrar na arena PvP | /rank  seu rank")
        return true, table.concat(t, "\n")
    end,
})

core.register_chatcommand("comprar", {
    params = "<item>",
    description = "Compra um item da loja",
    func = function(name, param)
        param = param or ""
        param = param:gsub("^%s+", ""):gsub("%s+$", "")
        local achou
        for _, it in ipairs(LOJA) do if it.id == param then achou = it end end
        if not achou then return false, "Item invalido. Use /loja" end
        bought[name] = bought[name] or {}
        if bought[name][achou.id] then return false, "Voce ja tem esse item" end
        if (coins[name] or 0) < achou.preco then return false, "Moedas insuficientes: " .. (coins[name] or 0) .. "/" .. achou.preco end
        coins[name] = coins[name] - achou.preco
        bought[name][achou.id] = true
        local p = core.get_player_by_name(name)
        if p then achou.aplica(p); atualizarHud(p) end
        salvar()
        return true, "Comprou: " .. achou.nome .. " (sobrou " .. coins[name] .. ")"
    end,
})

core.register_chatcommand("rank", {
    description = "Mostra seu rank",
    func = function(name)
        return true, "Rank: " .. rank(name) .. " | Moedas: " .. (coins[name] or 0)
    end,
})

-- ====== ENTRADA: da boas-vindas, aplica compras, cria lobby ======
local function construirLobby()
    local base = {x = 0, y = 10, z = 0}
    if core.get_node_or_nil(base) then return end
    for dx = -6, 6 do
        for dz = -6, 6 do
            core.set_node({x = base.x + dx, y = base.y, z = base.z + dz}, {name = "default:stone"})
        end
    end
    core.set_node({x = 0, y = 11, z = 0}, {name = "mw_rbx:moeda"})
    core.set_node({x = 2, y = 11, z = 2}, {name = "mw_rbx:moeda"})
    core.set_node({x = -2, y = 11, z = -2}, {name = "mw_rbx:pulapula"})
    core.set_node({x = 3, y = 11, z = -3}, {name = "mw_rbx:pulapula"})
end

core.register_on_joinplayer(function(p)
    local n = p:get_player_name()
    coins[n] = coins[n] or 0
    hud(p)
    p:set_pos({x = 0.5, y = 12, z = 0.5})
    if bought[n] then
        if bought[n].velocidade then p:set_physics_override({speed = 1.3}) end
        if bought[n].pulo then p:set_physics_override({jump = 1.5}) end
    end
    core.after(1, construirLobby)
    core.chat_send_player(n, core.colorize("#FFD319", "Bem-vindo ao MONTROY WORLD!") .. "  /loja para comprar, /arena para PvP")
end)

core.register_on_leaveplayer(function(p)
    coins[p:get_player_name()] = coins[p:get_player_name()] or 0
    salvar()
end)

carregar()
core.log("action", "Montroy World carregado")
